Test cases
- Not online, click, wait and send
- Not online, click, click and don't send
- Online, click and send

Images:
https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn.iconscout.com%2Ficon%2Ffree%2Fpng-256%2Fchat-1323-439048.png&imgrefurl=https%3A%2F%2Ficonscout.com%2Ficon%2Fchat-1323&tbnid=iTbQOcHz7oB3fM&vet=12ahUKEwjV5rzSj5L1AhWcM7kGHfEaDroQMygIegUIARD3AQ..i&docid=H7gPIsguoNN5ZM&w=256&h=256&itg=1&q=chat%20icon%20png&hl=pt-BR&ved=2ahUKEwjV5rzSj5L1AhWcM7kGHfEaDroQMygIegUIARD3AQ
https://www.google.com/imgres?imgurl=https%3A%2F%2Fstatic.thenounproject.com%2Fpng%2F1378069-200.png&imgrefurl=https%3A%2F%2Fthenounproject.com%2Fterm%2Ffish-hook%2F1378069%2F&tbnid=Wy32jvqjsoLkgM&vet=12ahUKEwj5ytvxj5L1AhVQA7kGHZr-CUMQMygDegUIARDqAQ..i&docid=GWWLyG12zv4wJM&w=200&h=200&q=hook%20icon%20png&hl=pt-BR&ved=2ahUKEwj5ytvxj5L1AhVQA7kGHZr-CUMQMygDegUIARDqAQ
